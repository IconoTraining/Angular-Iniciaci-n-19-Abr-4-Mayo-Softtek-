import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { AgendaService } from './services/agenda.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  contactos: any = [];
  id: string = '';
  amigo:any;
  activarModificacion: boolean = false;

  amigoForm = new FormGroup({
    nombre: new FormControl(),
    telefono: new FormControl()
  });

  constructor(private agendaService: AgendaService){}

  modificar(){
    this.activarModificacion = true;
    this.amigoForm.setValue({
      nombre: this.amigo.nombre,
      telefono: this.amigo.telefono
    });
  }

  guardar(){
    this.agendaService.modificarAmigo(this.id, this.amigoForm.value).then(() => {
      alert("Contacto modificado");
      this.amigoForm.reset();
    }, (error: any) => {
      console.log(error);
    });
  }

  borrar(){
    this.agendaService.borrarAmigo(this.id).then(() => {
      alert("Contacto eliminado");
    }, (error: any) => {
      console.log(error);
    });
  }

  alta(){
    this.agendaService.altaAmigo(this.amigoForm.value).then(() => {
      alert("Contacto creado");
      this.amigoForm.reset();
    }, (error: any) => {
      console.log(error);
    });
  }

  buscar(){
    this.agendaService.buscarAmigo(this.id).subscribe( (item:any) => {
        console.log(item.payload.data());
        this.amigo = item.payload.data();
    });
  }

  ngOnInit(): void {
      this.agendaService.todosAmigos().subscribe((datos: any) => {

          // Limpiar el array
          this.contactos = [];
          console.log(datos);

          datos.forEach( (element:any) => {
            this.contactos.push(element.payload.doc.data());
          });
      });
  }

}
