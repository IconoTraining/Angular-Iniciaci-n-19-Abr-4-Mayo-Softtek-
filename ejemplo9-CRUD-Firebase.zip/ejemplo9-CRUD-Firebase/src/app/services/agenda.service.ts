import { Injectable } from "@angular/core";
import { AngularFirestore } from "@angular/fire/firestore";

@Injectable({
    providedIn: 'root'
})

export class AgendaService{

    constructor(private angularFirestore: AngularFirestore){}

    public todosAmigos(): any{
        return this.angularFirestore.collection('agenda').snapshotChanges();
    }

    public buscarAmigo(id: string): any{
        return this.angularFirestore.collection('agenda').doc(id).snapshotChanges();
    }

    public altaAmigo(nuevo: any): any{
        return this.angularFirestore.collection('agenda').add(nuevo);
    }

    public borrarAmigo(id: string): any{
        return this.angularFirestore.collection('agenda').doc(id).delete();
    }

    public modificarAmigo(id: string, data: any): any{
        return this.angularFirestore.collection('agenda').doc(id).set(data);
    }

}


