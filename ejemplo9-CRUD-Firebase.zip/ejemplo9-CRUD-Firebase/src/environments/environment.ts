// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyA8Oke41weK0o3BYlZrtw6FntgIBKKy3PA",
    authDomain: "angular-softtek-ana.firebaseapp.com",
    projectId: "angular-softtek-ana",
    storageBucket: "angular-softtek-ana.appspot.com",
    messagingSenderId: "979483694203",
    appId: "1:979483694203:web:8d8a7f67913e8c27b2bede"
  }
  
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
