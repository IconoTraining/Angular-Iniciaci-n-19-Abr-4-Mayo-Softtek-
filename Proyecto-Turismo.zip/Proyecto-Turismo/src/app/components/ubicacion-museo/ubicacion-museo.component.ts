import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ubicacion-museo',
  templateUrl: './ubicacion-museo.component.html',
  styleUrls: ['./ubicacion-museo.component.css']
})
export class UbicacionMuseoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
