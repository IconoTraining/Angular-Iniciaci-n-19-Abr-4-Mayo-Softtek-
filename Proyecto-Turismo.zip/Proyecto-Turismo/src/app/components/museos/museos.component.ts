import { Component } from '@angular/core';

@Component({
  selector: 'app-museos',
  templateUrl: './museos.component.html',
  styleUrls: ['./museos.component.css']
})
export class MuseosComponent {

  museos: any = [
    {id:1, nombre: 'Museo del Prado'},
    {id:2, nombre: 'Reina Sofia'},
    {id:3, nombre: 'Biblioteca nacional'},
    {id:4, nombre: 'Thyssen'}
  ];

  constructor() { }

  

}
