import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Museo } from 'src/app/models/museo';

@Component({
  selector: 'app-museo-detalle',
  templateUrl: './museo-detalle.component.html',
  styleUrls: ['./museo-detalle.component.css']
})
export class MuseoDetalleComponent implements OnInit {

  museo: Museo;
  id: number;

  museos: Museo[] = [
    {id:1,nombre:'Museo del Prado',telefono:'913 30 28 00',direccion:'Calle de Ruiz de Alarcón, 23, 28014 Madrid',horario:'10:00 – 20:00',imagen:'../../../assets/Museo_del_Prado.jpeg',web:'https://www.museodelprado.es/',coordenadas:[40.4137818,-3.6921271],precio:15,abierto:true},
    {id:2,nombre:'Reina Sofia',telefono:'917741000',direccion:'Calle Santa Isabel',horario:'Cierra a las 21:00',imagen:'../../../assets/Reina_Sofia.jpeg',web:'https://www.museoreinasofia.es/',coordenadas:[40.408644,-3.693992],precio:15,abierto:true },
    {id:3,nombre:'Biblioteca Nacional',telefono:' 91 516 89 67 / 91 580 77 59',direccion:'Paseo de Recoletos, 20-22. 28071. Madrid.',horario:'1De Martes a Sabado de 10 a 20 h. Domingos de 10 a 14 h.',imagen:'../../../assets/Biblioteca_Nacional.jpeg',web:'museo@bne.es',coordenadas:[40.42348498519113, -3.6910447306827954],precio:0,abierto:true},
    {id:4,nombre:"Museo Thyssen",telefono:'917911370',direccion:"Paseo del Prado, 8",horario:'10:00 a 19:00',imagen:'../../../assets/Thyssen.jpeg',web:'https://www.museothyssen.org/',coordenadas:[40.416137331924666, -3.694930865545187],precio:13,abierto:true}
  ];

  constructor(private ruta: ActivatedRoute) { 
      this.id = this.ruta.snapshot.params['codigo'];
      this.museo = this.buscarMuseo();
  }

  buscarMuseo(): Museo{
    return this.museos.filter((item) => {
      return item.id == this.id
    })[0];
  }

  ngOnInit(): void {
  }

}
