import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { MuseosComponent } from './components/museos/museos.component';
import { MuseoDetalleComponent } from './components/museo-detalle/museo-detalle.component';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AgmCoreModule } from '@agm/core';
import { UbicacionMuseoComponent } from './components/ubicacion-museo/ubicacion-museo.component';

// Declarar las rutas asociadas a cada componente
const misRutas: Routes = [
  {path:'home', component: HomeComponent},
  {path:'museos', component: MuseosComponent},
  {path:'museo_detalle/:codigo', component:MuseoDetalleComponent},
  {path:'ubicacion_museo', component: UbicacionMuseoComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    MuseosComponent,
    MuseoDetalleComponent,
    HomeComponent,
    UbicacionMuseoComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(misRutas),
    HttpClientModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: (http: HttpClient) => {
          return new TranslateHttpLoader(http);
        },
        deps: [HttpClient]
      }
    }),
    AgmCoreModule.forRoot({
      apiKey: ''
    })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
