import { Component } from '@angular/core';
import { PokemonService } from './services/pokemon.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  pokemons: any = [];
  nombre: string = '';
  pokemon: any = null;
  
  constructor(private pokemonService: PokemonService){
    
    // Asi no se puede lanzar la peticion
    //this.pokemons = this.pokemonService.getAll();

    this.pokemonService.getAll().subscribe( (datos:any) => {
      console.log(datos);
      this.pokemons = datos['results'];
    });

  }

  buscar(){
    this.pokemonService.buscar(this.nombre).subscribe( (item: any) => {
      console.log(item);
      this.pokemon = item;
    });
  }

}
