import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
    nombre: string = 'Pepito';
    apellido: string = "Perez";

    habilitado: boolean = true;

    estilo = 'rojo';

    constructor(){
        setTimeout( () => {
          this.habilitado = false;
        }, 3000);
    }

    saludar(): void{
      alert("Bienvenido a Angular !!!");
    }
}
