import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  texto: string = "Bienvenido al curso de Angular";
  numero: number = 7788.654568998764323356;
  porcentaje: number = 0.54886;
  fecha: Date = new Date();
  jsonObjeto = {nombre:'Juan',edad:36,telefonos:{tel1:916543289,tel2:616123456}};
}
